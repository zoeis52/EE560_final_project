%Please only have a look at the files starting with 'demo_'. All other
%files are obsolete and should be moved away.
