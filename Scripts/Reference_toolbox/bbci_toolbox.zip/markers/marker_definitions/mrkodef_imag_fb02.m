function mrk= mrkodef_imag_fb02(mrko, opt)

mrk= mrkodef_imag_fb01(mrko, opt);

