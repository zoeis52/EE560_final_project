function mrk= mrkodef_real_arrow(varargin)

mrk= mrkodef_imag_arrow(varargin{:});
