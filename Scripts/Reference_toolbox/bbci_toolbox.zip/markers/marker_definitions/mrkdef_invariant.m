function mrk= mrkdef_invariant(Mrk, file, opt)

opt.logf= [];
opt.flogf= [];
mrk= mrkdef_imag_fb1d(Mrk, file, opt);
