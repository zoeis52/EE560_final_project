function mrk= mrkdef_fixed_seq_audiF(mrko)
classDef = {[31:36],[21:26];'target-fix','non-target-fix'};
mrk = mrk_defineClasses(mrko, classDef);
