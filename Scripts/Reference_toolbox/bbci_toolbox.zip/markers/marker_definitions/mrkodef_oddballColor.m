function mrk= mrkodef_oddballColor(mrko, varargin)

mrk= mrkodef_general_oddball(mrko, 'respDef',[]);
