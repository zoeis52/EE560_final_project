function mrk= mrkodef_imag_fb03(mrko, opt)

mrk= mrkodef_imag_fb01(mrko, opt);
