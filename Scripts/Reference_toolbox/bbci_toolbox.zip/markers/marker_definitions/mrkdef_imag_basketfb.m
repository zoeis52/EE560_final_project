function mrk= mrkdef_imag_basketfb(Mrk, file, opt)
% see mrkdef_imag_fbbasket

mrk= mrkdef_imag_fbbasket(Mrk, file, opt);
