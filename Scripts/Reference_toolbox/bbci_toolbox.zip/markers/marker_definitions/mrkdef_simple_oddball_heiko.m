function mrk= mrkdef_simple_oddball_heiko(Mrk)

classDef= {1, 21; 'std','dev'};
mrk= makeClassMarkers(Mrk, classDef,0,0);
