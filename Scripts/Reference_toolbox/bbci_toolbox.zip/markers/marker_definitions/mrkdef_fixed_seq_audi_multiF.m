function mrk= mrkdef_fixed_seq_audi_multiF(mrko)
classDef = {[31],[32],[33],[34],[35],[36],[21],[22],[23],[24],[25],[26];'target-fix1','target-fix2','target-fix3','target-fix4','target-fix5','target-fix6',...
   'non-target-fix1','non-target-fix2','non-target-fix3','non-target-fix4','non-target-fix5','non-target-fix6'};
mrk = mrk_defineClasses(mrko, classDef);
