function mrk= mrkodef_rest(mrko, opt)

stimDef= {5, 7;
          'start', ...          
          'stop'}; 
mrk= mrk_defineClasses(mrko, stimDef);