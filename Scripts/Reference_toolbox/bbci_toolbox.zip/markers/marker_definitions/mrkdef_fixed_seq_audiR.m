function mrk= mrkdef_fixed_seq_audiR(mrko)
classDef = {[11:16],[1:6];'target','non-target'};
mrk = mrk_defineClasses(mrko, classDef);
