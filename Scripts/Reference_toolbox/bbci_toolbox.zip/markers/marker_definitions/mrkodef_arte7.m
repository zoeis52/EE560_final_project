function mrk= mrkodef_arte7(varargin)

mrk= mrkodef_artifacts(varargin{:});
