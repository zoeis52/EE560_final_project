function mrk= mrkdef_imag_1d(varargin)
%function obsolete, use mrkdef_imag_fb1d.

mrk= mrkdef_imag_fb1d(varargin{:});
