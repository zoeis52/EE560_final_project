function mrk = sepfinger(mrk);

error('function is obsolete. Use trennfinger!');

