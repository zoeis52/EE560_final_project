function y= apply_nothing(C, y)
% APPLY_NOTHING is used in online feedback, when a specific feature
%  should be used as feedback signal insteady of a classfier output.
