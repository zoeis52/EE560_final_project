function out = apply_mkl_xval(C,dat);

out = apply_mkl(C,dat);
